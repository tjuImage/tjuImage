﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using Microsoft.Kinect;
using System.IO;
using Microsoft.ProjectOxford.Emotion;
using Microsoft.ProjectOxford.Emotion.Contract;
using System.Threading;
namespace finalProject
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private static KinectSensor _kinect;
        private static  KinectAudioSource _audioSource;
        public static String path = @"picture";
        public static bool ready = true;
        public volatile static bool isStart = true;
        public Thread voice_thread;
        public MainWindow()
        {
            //window.IsEnabled = false;
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //start.IsEnabled = false;
           // stop.IsEnabled = false;
           // resume.IsEnabled = false;
           // pause.IsEnabled = false;
            //window.IsEnabled = false;
            //window.IsEnabled = true;
            angle_scoller.Value = 0.5;
            angle_scoller.IsEnabled = false;
            startKinect();
            Thread t = new Thread(init_kinect);
            t.Start();
            //start.IsEnabled = true;
        }

        /// <summary>
        /// 启动Kinect设备,初始化选项，并注册AllFramesReady同步事件
        /// </summary>
        private void startKinect()
        {
            messageBox.Content = "Init.......";
            if (KinectSensor.KinectSensors.Count > 0)
            {
                //选择第一个kinect设备
                _kinect = KinectSensor.KinectSensors.FirstOrDefault();
                //MessageBox.Show("Kinect目前的状态为： " + _kinect.Status);
               

                //初始化设定，启用颜色图像、深度图像和骨骼跟踪
                _kinect.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);
                _kinect.DepthStream.Enable(DepthImageFormat.Resolution640x480Fps30);
                _kinect.SkeletonStream.Enable();

                //注册时间，该方法将保证彩色图像、深度图像和骨骼数据的同步
                //  _kinect.AllFramesReady +=
                //      new EventHandler<AllFramesReadyEventArgs>(_kinect_AllFramesReady);

                //注册保证彩色图像的同步
                _kinect.ColorFrameReady += new EventHandler<ColorImageFrameReadyEventArgs>(
                    _kinect_ColorFrameReady);

                //注册骨骼信息数据的同步
                //_kinect.SkeletonFrameReady +=
                //    new EventHandler<SkeletonFrameReadyEventArgs>(_kinect_SkeletFrameReady);
                

                //开启音频录制
                _audioSource = _kinect.AudioSource;
                _audioSource.AutomaticGainControlEnabled = false;
                //MessageBox.Show("Yes");

                //开启kinect;
                //_kinect.Start();
                //_kinect.ElevationAngle = 0;
                //MessageBox.Show("开始工作");

                //voice_thread = new Thread(test);
                //start.IsEnabled = true;
            /*    t.Start();
                /*while (true)
                {
                    VoiceControls.voiceRecord(_audioSource);
                }*/
            }
            else
            {
                MessageBox.Show("没有发现任何设备！");
            }
        }

        public static void test()
        {
            while (true)
            {
                if (isStart) continue;
                VoiceControls.voiceRecord(_audioSource);
            }
        }

        public void init_kinect()
        {
            //startKinect();
            _kinect.Start();
            //_kinect.ElevationAngle = 0;
            ready = false;
            //start.IsEnabled = true;
        }

        public void startVoice()
        {
            voice_thread = new Thread(test);
            voice_thread.Start();
            /*while (true)
            {
                try
                {
                    voice_thread.Start();
                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }*/
        }

        private void _kinect_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            //显示彩色摄像头
            using (ColorImageFrame colorFrame = e.OpenColorImageFrame())
            {
                if (colorFrame == null)
                    return;
                byte[] pixels = new byte[colorFrame.PixelDataLength];
                colorFrame.CopyPixelDataTo(pixels);
                
                //BGR32格式图片一个像素为4个字节
                int stride = colorFrame.Width * 4;
                //获取当前的kinect得到的彩色图像
                BitmapSource bitmap = BitmapSource.Create(colorFrame.Width, colorFrame.Height,
                        96, 96, PixelFormats.Bgr32, null, pixels, stride);
                video.Source = bitmap;
                //BitmapSource bitmap = ColorFrameControls.getBitmapSourceFromVideo(colorFrame);
                //imageCamera.Source = bitmap;
                if (ready);
                else
                {
                    messageBox.Content = _kinect.Status;
                    start.IsEnabled = true;
                    angle_scoller.IsEnabled = true;
                    ready = true;
                }
                if (isStart) return;
                BitmapSource m = (BitmapSource)bitmap;
                String filePath = ColorFrameControls.savePicture(m, path);
                if (filePath.Equals("NoFile")) ;
                else EmotionDetection.getAnswer(filePath);
            }
        }

        private void start_Click(object sender, RoutedEventArgs e)
        {
            //if (voice_thread.ThreadState == ThreadState.Suspended)
            //     voice_thread.Resume();
           //  else 
            startVoice();
            isStart = false;
            start.IsEnabled = false;
            stop.IsEnabled = true;
            resume.IsEnabled = false;
            pause.IsEnabled = true;
            BrowserController.show_message();
        }

        private void video_Loaded(object sender, RoutedEventArgs e)
        {
            //startKinect();
        }

        private void stop_Loaded(object sender, RoutedEventArgs e)
        {
            //startKinect();
        }

        private void pause_Click(object sender, RoutedEventArgs e)
        {
            isStart = true;
            start.IsEnabled = false;
            pause.IsEnabled = false;
            resume.IsEnabled = true;
            stop.IsEnabled = true;
            //voice_thread.Suspend();
        }

        private void resume_Click(object sender, RoutedEventArgs e)
        {
            isStart = false;
            start.IsEnabled = false;
            pause.IsEnabled = true;
            resume.IsEnabled = false;
            stop.IsEnabled = true;
        }

        private void stop_Click(object sender, RoutedEventArgs e)
        {
            isStart = true;
            start.IsEnabled = true;
            pause.IsEnabled = false;
            resume.IsEnabled = false;
            stop.IsEnabled = false;
            //voice_thread.Suspend();
            voice_thread.Abort();
        }

        private void Window_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            //startKinect();
        }

        private void angle_scoller_KeyUp(object sender, KeyEventArgs e)
        {
           /* Console.WriteLine("YES");
            if (angle_message.Value > 9) return;
            else angle_message.Value += 1;*/
        }

        private void angle_scoller_KeyDown(object sender, KeyEventArgs e)
        {
            /*if (angle_message.Value < 1) return;
            else angle_message.Value -= 1;*/
        }

        private void angle_scoller_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
        {
            double value = angle_message.Value;
            angle_message.Value = (1-angle_scoller.Value) * 10;
            if (angle_message.Value > value )
            {
                _kinect.ElevationAngle += 5;
            }
            else if (angle_message.Value < value)
            {
                _kinect.ElevationAngle -= 5;
            }
            else return;
        }
    }
}
