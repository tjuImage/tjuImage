﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalProject
{
    class Dic
    {
        /// <summary>
        /// doubiyuxuehui
        /// </summary>
        public static Dictionary<String,String> dic = new Dictionary<String,String>();

        private Dic() { }

        public static void add ( String key , String value ){
            lock ( dic )
            {
                print("[Message] : add (" + key + "," + value + ") in Dic", 0);
                dic.Add(key, value);
            }
        }

        /// <summary>
        /// 获取到时间
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static String get (String key)
        {
            lock (dic)
            {
                String value = null;
                try
                {
                    value = dic[key];
                }
                catch (Exception e)
                {
                    print("[error] : " + e.Message + " in key '"+ key + "'", 1);
                    return value;
                }
                return value;
            }
        }

        public static void print(String str, int type){
            ConsoleColor cc = Console.ForegroundColor;
            if (type == 0) Console.ForegroundColor = ConsoleColor.Yellow;
            else if (type == 1) Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(str);
            Console.ForegroundColor = cc;
        }
    }
}
