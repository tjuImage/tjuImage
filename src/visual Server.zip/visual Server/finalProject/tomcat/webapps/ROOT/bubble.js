var bubbleColor = d3.scale.category10();
var first_Enter = 1;
  var svgContainer;
  var circles;
function drawBubble(bubbleData){ //回调函数
  d3.selectAll(".bubbleSvg").remove();

  var temp = bubbleData[bubbleData.length -1];
  var max = 30 / Math.max(parseFloat(temp.Anger),parseFloat(temp.Contempt),parseFloat(temp.Disgust),
                     parseFloat(temp.Fear),parseFloat(temp.Sadness), parseFloat(temp.Neutral),
                     parseFloat(temp.Happiness),parseFloat(temp.Surprise));
  // console.log(max);
  var data = [
              {type : "Anger", x_axis : 30, y_axis : 30, radius : parseFloat(temp.Anger) * max+10},
              {type : "Contempt", x_axis : 80, y_axis : 70, radius : parseFloat(temp.Contempt) * max+10},
              {type : "Disgust", x_axis : 130, y_axis : 110, radius : parseFloat(temp.Disgust) * max+10},
              {type : "Fear", x_axis : 180, y_axis : 150, radius : parseFloat(temp.Fear) * max+10},
              {type : "Sadness", x_axis : 230, y_axis : 190, radius : parseFloat(temp.Sadness) * max+10},
              {type : "Neutral", x_axis : 280, y_axis : 230, radius : parseFloat(temp.Neutral) * max+10},
              {type : "Happiness", x_axis : 320, y_axis : 270, radius : parseFloat(temp.Happiness) * max+10},
              {type : "Surprise", x_axis : 380, y_axis : 310, radius : parseFloat(temp.Surprise) * max+10}
              ]
  // console.log(data);
  // console.log(data);


  svgContainer = d3.select(".panel3").append("svg")
  									.attr("class","bubbleSvg")
                                    .attr("width", 500)
                                    .attr("height", 495);
                                
  circles = svgContainer.selectAll("circle")
                          //.data(jsonCircles)
                          .data(data)
                          .enter()
                          .append("circle");
   svgContainer.selectAll("text")
              .data(data)
              .enter()
              .append("text")
              .attr("x",function(d){return d.x_axis-20;})
              .attr("y",function(d){return 430;})
               .attr("dy", ".71em")
              .text(function(d){return d.type;})
              .attr("font-size","11px")
     circles
            .attr("cx", function (d) { return d.x_axis; })
            .attr("cy", function (d) { return 500 - 10 * d.radius; })
            .attr("r", function (d) { return d.radius; })
            .style("fill", function(d) { return color(d.type); });
    
        circles
            .attr("cx", function (d) { return d.x_axis; })
            .attr("cy", function (d) { return 500 - 10 * d.radius; })
            .attr("r", function (d) { return d.radius; })
            .style("fill", function(d) { return color(d.type); })
            ;      
 
  
 
}

