var isFirstLoad = true;
var svg_flowmap = d3.select(".panel1").append("svg");
var dataCountPer = 5;
var delayGet = 5700;
var color = d3.scale.category10();

function showFolowMap(data){
    if(isFirstLoad) {
        drawFlowMap(data);
        isFirstLoad = false;
    }else{
        drawFlowMap(data, true, delayGet);
    }

    function drawFlowMap(data,transition, duration){
        var m = dataCountPer > data.length ? data.length : dataCountPer;
        // 数据预处理
        var usedata = [];
        for(var i = data.length - m; i < data.length; i++){
            data[i].date = new Date(data[i].date);
            usedata.push(data[i])
        }
        data = usedata;

        data.sort(function(a,b){return a.date - b.date});
        var attrs = ["Anger", "Contempt", "Disgust", "Fear", "Sadness", "Neutral", "Happiness", "Surprise"];

        // 相关参数设置, n 是情感种类， m是每次在图中显示的数据条数， width，height是整个图的大小，color是图的颜色设置
        // maxDataValue是数据中最大的数值
        var n = 8;
        var width = 960, height = 200;
        var maxDataValue = 1.0;

        // 添加 svg
        svg_flowmap .attr("width", width).attr("height", height);

        // 根据数据生成path的函数
        var x = d3.scale.linear()
            .domain([0, m - 1])
            .range([0, width]);
        var y = d3.scale.linear()
            .domain([0, maxDataValue])
            .range([height, 0]);
        var area = d3.svg.area()
            .x(function(d) { return x(d.x); })
            .y0(function(d) { return y(d.y0); })
            .y1(function(d) { return y(d.y0 + d.y); });

        drawData(data,transition, duration);

        function drawData(data, transition, duration) {
            function generateLayer(data, attr) {
                var a = [];
                for (var i = 0; i < data.length; i++) {
                    a.push({x: i, y: +data[i][attr] +.001});
                }
                return a;
            }

            var stack = d3.layout.stack().offset("wiggle");
            var layers = stack(d3.range(n).map(function (d, i) {
                return generateLayer(data, attrs[i]);
            }));

            if(transition == true) {
                svg_flowmap.selectAll("path")
                    .data(layers)
                    .transition()
                    .duration(duration)
                    .attr("d", area);
            }else{
                svg_flowmap.selectAll("path")
                    .data(layers)
                    .enter().append("path")
                    .attr("d", area)
                    .style("fill", function (d,i) {
                        return color(attrs[i]);
                    });
            }
        }
    }
}
