﻿using Microsoft.ProjectOxford.Emotion.Contract;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace D3DataGenerate
{
    class EmotionData
    {
        public string date;
        public List<float> probability;
    }
    class EmotionVoiceData : EmotionData{
        public EmotionVoiceData(string _date="")
        {
            date = _date;                          // 不从xml中获取
            probability = new List<float>(5);
        }
    }
    class EmotionImageData : EmotionData
    {
        public EmotionImageData(string _date = "")
        {
            date = _date;                          // 不从xml中获取
            probability = new List<float>(8);
        }
    }

    enum FILETYPE { IMAGE, VOICE, BOTH}

    class EmotionWriterTool{
        public static void write(string path, string str)
        {
            FileStream fs = new FileStream(path, FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(str);
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();
        }

        public static void create(string path, FILETYPE filetype, int type = 0)
        {
            string str = "";
            if (type == 0)      // csv
            {
                switch (filetype)
                {
                    case FILETYPE.IMAGE:
                        str += "date,Anger,Contempt,Disgust,Fear,Sadness,Neutral,Happiness,Surprise\n";
                        break;
                    case FILETYPE.VOICE:
                        str += "date,NegativeActive,NegativePassive,Neutral,PositivePassive,PositiveActive\n";
                        break;
                    case FILETYPE.BOTH:
                        str += "date,[emotions]\n";
                        break;
                }
            }
            FileStream fs = new FileStream(path, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(str);
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();
        }

        // 持久化数据
        public static string getDataStr(EmotionData emotionData, int type = 0)
        {
            string data = "";
            if (type == 0)                          // csv 格式
            {
                data = emotionData.date + ",";
                for (int i = 0; i < emotionData.probability.Count-1; i++)
                {
                    data += emotionData.probability[i].ToString() + ",";
                }
                if (emotionData.probability.Count > 0)
                {
                    data += emotionData.probability[emotionData.probability.Count - 1].ToString() + "\n";
                    //data += "inside" + emotionData.probability.Count;
                }
            }
            return data;
        }

    }

    class D3DataGenerate
    {
        static void Main1(string[] args)
        {
            //string wavfilepath = "test.wav";
            //D3DataGenerate.getInstance().saveVoiceEmotion(wavfilepath);
            
            for (int j = 0; j < 100; j++)
            {
                EmotionImageData imageData = new EmotionImageData();
                for (int i = 0; i < 8; i++) { imageData.probability.Add(i); }
                D3DataGenerate.getInstance().saveImageEmotion(imageData);
            }
            D3DataGenerate.getInstance().endLoop();
        }

        public void endLoop()
        {
            D3DataGenerate.getInstance().emotionFromImage.endLoop = true;
        }

        struct FilePath
        {
            public string currentVoiceFile;
            public string currentBothFile;
        } 
        FilePath filepath;

        string tomcatPath = @"..\..\tomcat\webapps\ROOT\";
        private D3DataGenerate()
        {
            filepath.currentVoiceFile = tomcatPath + "voice_data0.csv";
            emotionFromImage.currentImageFile = tomcatPath + "image_data0.csv";
            filepath.currentBothFile = "both_data0.csv";
            EmotionWriterTool.create(filepath.currentVoiceFile, FILETYPE.VOICE);
            EmotionWriterTool.create(emotionFromImage.currentImageFile, FILETYPE.IMAGE);
            EmotionWriterTool.create(filepath.currentBothFile, FILETYPE.BOTH);
        }

        // 单例模式构建函数
        static D3DataGenerate d3DataGenerate = null;
        public static D3DataGenerate getInstance()
        {
            if (d3DataGenerate == null) d3DataGenerate = new D3DataGenerate();
            return d3DataGenerate;
        }

        // 图pain数据处理
        protected EmotionFromImage emotionFromImage = new EmotionFromImage();
        void saveImageEmotion(EmotionImageData emotionData){
            emotionFromImage.saveEmotion(emotionData);
        }

        public void saveImageEmotion(string date, Emotion emotion)
        {
            EmotionImageData emotionData = new EmotionImageData();
            emotionData.date = date;
            emotionData.probability.Add(emotion.Scores.Anger);
            emotionData.probability.Add(emotion.Scores.Contempt);
            emotionData.probability.Add(emotion.Scores.Disgust);
            emotionData.probability.Add(emotion.Scores.Fear);
            emotionData.probability.Add(emotion.Scores.Sadness);
            emotionData.probability.Add(emotion.Scores.Neutral);
            emotionData.probability.Add(emotion.Scores.Happiness);
            emotionData.probability.Add(emotion.Scores.Surprise);
            saveImageEmotion(emotionData);
        }

        // 声音文件处理
        protected EmtionFromWav emotionFromWav = new EmtionFromWav();
        public void saveVoiceEmotion(string wavfilepath)
        {
            emotionFromWav.runEmoVoice(wavfilepath);
            EmotionVoiceData emotionData = emotionFromWav.readOneEmotionFromXml(wavfilepath);
            Console.WriteLine("[Message]: save voice emtion of " + wavfilepath);
            EmotionWriterTool.write(filepath.currentVoiceFile, EmotionWriterTool.getDataStr(emotionData));
        }

        

    }
}
