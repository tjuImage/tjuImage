﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace D3DataGenerate
{
    class EmtionFromWav
    {
        string modelDir = @"..\..\emovoice\";
        const string emovoicePath = @"..\..\emovoice\EmotionVoice.exe";
        const string wavDir = @"..\..\emovoice\test\";
        const string xmlDir = @"..\..\emovoice\xml\";
        const string frame = "0.5";

        // 运行程序由wav获得xml
        public void runEmoVoice(string wavfilepath)
        {
            System.Diagnostics.Process myProcess = new System.Diagnostics.Process();
            myProcess.StartInfo.UseShellExecute = false;
            myProcess.StartInfo.RedirectStandardOutput = false;
            myProcess.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            myProcess.StartInfo.FileName = emovoicePath;
            myProcess.StartInfo.Arguments = "-h -f " + frame + " -d " + modelDir + " " + finalProject.VoiceControls.path + wavfilepath + " " + xmlDir + wavfilepath + " 2.";
            //Console.WriteLine("-h -f " + frame + " -d " + modelDir + " " + finalProject.VoiceControls.path + wavfilepath + " " + xmlDir + wavfilepath + " 2.");
            myProcess.Start();

            while (!myProcess.HasExited)
            {
                myProcess.WaitForExit();
            }
            int returnValue = myProcess.ExitCode;
        }

        // 从一个情绪xml文件中读取数据，最终合并成一组数据
        public EmotionVoiceData readOneEmotionFromXml(string wavfilepath)
        {
            string filepath = EmtionFromWav.xmlDir + wavfilepath + ".events";
            EmotionVoiceData emotionData = new EmotionVoiceData();
            for(int i = 0; i < 5; i++) emotionData.probability.Add(0);

            if (wavfilepath.Length > 4)
                emotionData.date = wavfilepath.Substring(0, wavfilepath.Length - 4);

            List<EmotionVoiceData> emotionPros = readFromXml(filepath);
            foreach (EmotionVoiceData emotionPro in emotionPros)
            {
                for (int i = 0; i < 5; i++)
                    emotionData.probability[i] += emotionPro.probability[i];
            }
            if (emotionPros.Count != 0)
            {
                for (int i = 0; i < 5; i++)
                    emotionData.probability[i] /= emotionPros.Count;
            }
            return emotionData;
        }

        // 每个List<float> 是一个五维的声音数据，分别是该段声音为
        // NegativeActive、NegativePassive、Neutral、PositivePassive、PositiveActive的该概率
        public List<EmotionVoiceData> readFromXml(string filepath)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(filepath);
            XmlElement root = doc.DocumentElement;
            
            XmlNodeList eventNodes = root.SelectNodes("/events/event");
            List<EmotionVoiceData> emotionDataList = new List<EmotionVoiceData>();
            foreach (XmlNode eventNode in eventNodes)
            {
                XmlNodeList tupleNodes = eventNode.SelectNodes("tuple");
                EmotionVoiceData emotionData = new EmotionVoiceData();
                foreach (XmlNode tupleNode in tupleNodes)
                {
                    float pro = float.Parse(tupleNode.Attributes["value"].Value);
                    emotionData.probability.Add(pro);
                }

                emotionDataList.Add(emotionData);
            }

            return emotionDataList;
        }

    }
}
