﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace D3DataGenerate
{
    class EmotionFromImage
    {
        public string currentImageFile = "image_data0.csv";
        Queue<EmotionImageData> emotionQueue = new Queue<EmotionImageData>();
        public bool endLoop = false;
        public EmotionFromImage()
        {
            Thread thread = new Thread(new ThreadStart(saveEmotionQueueLoop));
            thread.Start();
        }

        // 在异步线程循环存储队列里的数据
        void saveEmotionQueueLoop()
        {
            while (true)
            {
                bool noempty;
                EmotionImageData emotionData = null;

                lock(emotionQueue){
                    noempty = emotionQueue.Count > 0;
                    if(noempty) emotionData = emotionQueue.Dequeue();
                }
                while (noempty)
                {
                    message("[message] : write image emotionData to file from Queue");
                    string str = EmotionWriterTool.getDataStr(emotionData);
                    EmotionWriterTool.write(currentImageFile, str);

                    lock (emotionQueue)
                    {
                        noempty = emotionQueue.Count > 0;
                        if (noempty)  emotionData = emotionQueue.Dequeue();
                    }
                }
                
                if (endLoop) break;

                // 每次队列空了后，进入wait队列，等待新的数据加入时进行唤醒
                lock (emotionQueue)
                {
                    //time++; // 统计次数，应统计停留时间，如果较长且进入次数较少，那么应保留
                    Monitor.Wait(emotionQueue, 3000);
                }
            }
        }

        public void saveEmotion(EmotionImageData emotionData)
        {
            lock (emotionQueue)
            {
                message("[message] : add image emotionData into Queue");
                emotionQueue.Enqueue(emotionData);
                Monitor.Pulse(emotionQueue);
            }
        }

        private void message(String str)
        {
            ConsoleColor cc =  Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(str);
            Console.ForegroundColor = cc;
        }

        
    }
}
