﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalProject
{
    class BrowserController
    {
        //public static string cmd = ""
        public static string serverName = @"..\..\tomcat\bin\startup.bat";
        public static string url = "http://localhost:8080/emmo.html";
        public static  string browser = "C:\\Program Files\\Internet Explorer\\iexplore";
        public static void show_message ( ){
            Process pro = new Process();
            FileInfo file = new FileInfo(serverName);
            pro.StartInfo.WorkingDirectory = file.Directory.FullName;
            pro.StartInfo.FileName = serverName;
            pro.StartInfo.CreateNoWindow = false;
            pro.Start();
            //pro.WaitForExit();
            /*System.Diagnostics.Process myProcess = new System.Diagnostics.Process();
            myProcess.StartInfo.UseShellExecute = false;
            myProcess.StartInfo.RedirectStandardOutput = false;
            myProcess.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            myProcess.StartInfo.FileName = serverName;
            //myProcess.StartInfo.Arguments ;//无参数，如有参数另行添加 
            myProcess.Start();
            while (!myProcess.HasExited)
            {
                myProcess.WaitForExit();
            }*/
            Process myProcess = new System.Diagnostics.Process();
            myProcess.StartInfo.UseShellExecute = false;
            myProcess.StartInfo.RedirectStandardOutput = false;
            myProcess.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            myProcess.StartInfo.FileName = browser;
            myProcess.StartInfo.Arguments = url;
            myProcess.Start();
            /*while (!myProcess.HasExited)
            {
                myProcess.WaitForExit();
            }*/


           // int returnValue = myProcess.ExitCode;
        }
    }
}
